from django.contrib import admin

from todo.models import TodoItem

admin.site.register(TodoItem)
